from django.contrib.auth import get_user_model
from rest_framework import serializers
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

from Auth.models import Student, Education, User


class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = ['email', 'name', 'mobile', 'password']


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    @classmethod
    def get_token(cls, user):
        token = super().get_token(user)
        # Add custom claims if needed
        return token


class CustomUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'email', 'name', 'is_staff', 'is_superuser', 'is_active')


class ProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'name', 'email', 'mobile', 'profile', 'gender', 'dob', 'religion',
                  'category', 'country', 'state', 'city', 'current_address','permanent_address' ,'zipcode','is_active','is_staff']

class BlogProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'name', 'email', 'profile', ]


class StudentProfileSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = ['id', 'name', 'email', 'mobile', 'profile', 'gender', 'dob', 'religion','category',
                  'course_interest', 'country', 'state', 'city', 'current_address','permanent_address', 'zipcode',]

class EducationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Education
        fields = '__all__'
