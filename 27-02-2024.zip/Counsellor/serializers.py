from rest_framework import serializers
from General.serializers import OnlyCourseCategorySerializer, OnlyCourseStreamSerializer, \
    OnlyCourseSubcategorySerializer, SimpleCourseCategorySerializer
from Auth.serializers import StudentProfileSerializer
from .models import *


class CounsellorSerializer(serializers.ModelSerializer):
    area_of_operation = SimpleCourseCategorySerializer(many=True, read_only=True)

    class Meta:
        model = Counsellor
        fields = '__all__'


class OrganizationTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrganizationType
        exclude = ('created_at', 'updated_at',)


class DirectorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Director
        fields = '__all__'


class CounsellorTestimonialSerializer(serializers.ModelSerializer):
    class Meta:
        model = CounsellorTestimonial
        fields = '__all__'


class LeadsSerializer(serializers.ModelSerializer):
    class Meta:
        model = Leads
        fields = '__all__'
        
        
class FAQSerializer(serializers.ModelSerializer):
    class Meta:
        model = FAQ
        fields = '__all__'


class OnlyCounsellorSerializer(serializers.ModelSerializer):
    area_of_operation = SimpleCourseCategorySerializer(many=True, read_only=True)

    class Meta:
        model = Counsellor
        fields = '__all__'


class OnlyDirectorSerializer(serializers.ModelSerializer):
    counsellor = SimpleCourseCategorySerializer(many=True, read_only=True)
    organization_type = OrganizationTypeSerializer(read_only=True)

    class Meta:
        model = Director
        fields = '__all__'


class OnlyCounsellorTestimonialSerializer(serializers.ModelSerializer):
    counsellor = SimpleCourseCategorySerializer(many=True, read_only=True)

    class Meta:
        model = CounsellorTestimonial
        fields = '__all__'


class OnlyLeadsSerializer(serializers.ModelSerializer):
    student = StudentProfileSerializer(read_only=True)
    course_category = OnlyCourseCategorySerializer(read_only=True)
    course_subcategory = OnlyCourseSubcategorySerializer(read_only=True)
    course_stream = OnlyCourseStreamSerializer(read_only=True)

    class Meta:
        model = Leads
        fields = '__all__'
