from django.shortcuts import render
from rest_framework.generics import ListAPIView, RetrieveAPIView,ListCreateAPIView
from rest_framework.permissions import AllowAny,IsAuthenticated
from django_filters import rest_framework as filters
from .models import Blog, Tag,Comment
from .serializers import BlogSerializer, SingleBlogSerializer, TagSerializer,CommentSerializer
from rest_framework.filters import SearchFilter

# Create your views here.

# class BlogListView(ListAPIView):
#     # queryset = Blog.objects.all()
#     serializer_class = SingleBlogSerializer
#     permission_classes = (AllowAny,)
    
#     def get_queryset(self):
#         return Blog.objects.filter(status='PUBLIC')


class BlogListFilter(filters.FilterSet):
    class Meta:
        model = Blog
        fields = {'category': ['exact']}

class BlogListView(ListAPIView):
    queryset = Blog.objects.filter(status='PUBLIC')
    serializer_class = SingleBlogSerializer
    permission_classes = [AllowAny]
    filter_backends = (filters.DjangoFilterBackend,SearchFilter)
    filterset_class = BlogListFilter
    search_fields = ['title', 'category__name',  'author__name',]

class BlogDetailView(RetrieveAPIView):
    queryset = Blog.objects.filter(status='PUBLIC')
    serializer_class = SingleBlogSerializer
    permission_classes = [AllowAny]
    lookup_field = 'slug'
    
    def get_object(self):
        blog = super().get_object()
        # Increase views when the blog is accessed
        blog.increase_views()
        return blog
        
        
class CommentListCreateView(ListCreateAPIView):
    queryset = Comment.objects.all()
    serializer_class = CommentSerializer
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
