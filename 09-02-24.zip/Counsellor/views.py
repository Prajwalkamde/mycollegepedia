from django.shortcuts import render
from rest_framework import viewsets
from rest_framework.generics import ListAPIView,CreateAPIView
from rest_framework.permissions import IsAuthenticated, AllowAny
from General.permissions import IsCounsellor
from .models import *
from .serializers import *


# Basic
class OrganizationTypeListView(ListAPIView):
    queryset = OrganizationType.objects.all()
    serializer_class = OrganizationTypeSerializer
    permission_classes = (AllowAny,)
    
    
class CounsellorViewOnly(viewsets.ModelViewSet):
    queryset = Counsellor.objects.all()
    serializer_class = CounsellorSerializer
    permission_classes = (AllowAny,)
    http_method_names = ['get',]
    lookup_field = 'slug'

class CounsellorTestimonialListView(ListAPIView):
    queryset = CounsellorTestimonial.objects.all()
    serializer_class = CounsellorTestimonialSerializer
    permission_classes = (AllowAny,)


class CounsellorApplicationCreateView(CreateAPIView):
    queryset = Leads.objects.all()
    serializer_class = LeadsSerializer
    permission_classes = (IsAuthenticated,)



class StudentAppliedCounsellorView(ListAPIView):
    serializer_class = OnlyLeadsSerializer
    permission_classes = (IsAuthenticated,)

    def get_queryset(self):
        student = self.request.user.student
        try:
            queryset = Leads.objects.filter(student=student)
            return queryset
        except CollegeAdmin.DoesNotExist:
            return Leads.objects.none()

    


# Counsellor Dashboard
class CounsellorViewSet(viewsets.ModelViewSet):
    queryset = Counsellor.objects.all()
    serializer_class = CounsellorSerializer
    permission_classes = [IsAuthenticated, IsCounsellor]
    http_method_names = ['get', 'post', 'put', 'patch', ]
    lookup_field = 'slug'

    def get_queryset(self):
        user = self.request.user
        if user.is_authenticated:
            return Counsellor.objects.filter(counsellor_user=user)
        else:
            return Counsellor.objects.none()


class DirectorViewSet(viewsets.ModelViewSet):
    queryset = Director.objects.all()
    serializer_class = DirectorSerializer
    # permission_classes = [IsAuthenticated, IsCounsellor]
    http_method_names = ['get', 'post', 'put', 'patch', 'delete']

    def get_queryset(self):
        user = self.request.user
        if user.is_authenticated:
            return Director.objects.filter(counsellor=user.counselloradmin.counsellor)
        else:
            return Director.objects.none()


class CounsellorTestimonialViewSet(viewsets.ModelViewSet):
    queryset = CounsellorTestimonial.objects.all()
    serializer_class = CounsellorTestimonialSerializer
    permission_classes = [IsAuthenticated, IsCounsellor]
    http_method_names = ['get', 'post', 'put', 'patch', 'delete']

    def get_queryset(self):
        user = self.request.user
        if user.is_authenticated:
            return CounsellorTestimonial.objects.filter(counsellor=user.counselloradmin.counsellor)
        else:
            return CounsellorTestimonial.objects.none()
    
    
class LeadsViewSet(viewsets.ModelViewSet):
    queryset = Leads.objects.all()
    serializer_class = OnlyLeadsSerializer
    permission_classes = [IsAuthenticated, IsCounsellor]
    http_method_names = ['get', 'put', 'patch']

    def get_queryset(self):
        counsellor_user = self.request.user.counselloradmin
        if counsellor_user.is_authenticated:
            return Leads.objects.filter(counsellor__counsellor_user=counsellor_user)
        else:
            return Leads.objects.none()
