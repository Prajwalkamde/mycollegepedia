from django.urls import path
from .views import BlogListView, BlogDetailView,CommentListCreateView

urlpatterns = [
    path('all-blog/', BlogListView.as_view(), name='all_blog'),
    path('blog-detail/<str:slug>/', BlogDetailView.as_view(), name='blog_detail'),
    path('comments/', CommentListCreateView.as_view(), name='comments'),
]
