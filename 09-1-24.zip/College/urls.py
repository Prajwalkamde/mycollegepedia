from django.urls import path,include
from rest_framework import routers
from College.views import CollegeListView, CollegeRetrieveView, CollegeGalleryRetrieveView, CourseFeeRetrieveView, \
    EligibilityRetrieveView, CourseFeeViewSet, CollegeApplicationCreateView, CollegeApplicationListView, \
    StudentAppliedCollegesView,CollegeAppliedCollegesView,CategoryCollegeView,AdmissionBlogListView,AdmissionBlogDetailView

router = routers.DefaultRouter()
router.register(r'coursefees', CourseFeeViewSet,basename='coursefees')
urlpatterns = [
    path('all-college/',CollegeListView.as_view(),name='all_college'),
    path('college/<str:slug>/',CollegeRetrieveView.as_view(),name='college'),
    path('college-gallery/<int:pk>',CollegeGalleryRetrieveView.as_view(),name='college_gallery'),
    path('course-fee/<int:pk>',CourseFeeRetrieveView.as_view(),name='course_fee'),
    # path('course-fee/',CourseFeeViewSet.as_view({'get': 'retrieve'}),name='all_course_fee'),
    path('apply/', CollegeApplicationCreateView.as_view(), name='apply-to-college'),
    path('student-applied-colleges/', StudentAppliedCollegesView.as_view(), name='student-applied-colleges'),
    path('college-applied-colleges/', CollegeAppliedCollegesView.as_view(), name='college-applied-colleges'),
    path('applications/', CollegeApplicationListView.as_view(), name='college-applications'),
    path('eligibility/<int:pk>',EligibilityRetrieveView.as_view(),name='eligibility'),
    path('category-colleges/', CategoryCollegeView.as_view(), name='category_colleges'),
    path('admission-blog/', AdmissionBlogListView.as_view(), name='admission_blog'),
    path('admission-blog-detail/<str:slug>/', AdmissionBlogDetailView.as_view(), name='admission_blog_detail'),
    path('', include(router.urls)),
]
