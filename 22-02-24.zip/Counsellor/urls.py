from django.urls import path,include
from rest_framework import routers
from .views import *

router = routers.DefaultRouter()
router.register(r'counsellor-detail', CounsellorViewSet,basename='counsellor-detail')
router.register(r'director-detail', DirectorViewSet,basename='director-detail')
router.register(r'counsellor-testimonial', CounsellorTestimonialViewSet,basename='counsellor-testimonial')
router.register(r'counsellor-leads', LeadsViewSet,basename='counsellor-leads')
router.register(r'counsellor', CounsellorViewOnly,basename='counsellor')
urlpatterns = [
   path('organization-type/',OrganizationTypeListView.as_view(),name='organization-type'),
   path('testimonial/',CounsellorTestimonialListView.as_view(),name='testimonial'),
   path('apply/', CounsellorApplicationCreateView.as_view(), name='apply'),
   path('student-apply/', StudentAppliedCounsellorView.as_view(), name='student-apply'),
   path('', include(router.urls)),
]
