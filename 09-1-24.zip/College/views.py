from django_filters.rest_framework import DjangoFilterBackend
from rest_framework import viewsets, generics
from rest_framework.filters import SearchFilter
from rest_framework.generics import ListAPIView, RetrieveAPIView
from rest_framework.permissions import AllowAny, IsAuthenticated
from rest_framework.views import APIView
from rest_framework.response import Response
from College.filters import CollegeFilter, CourseFeeFilter
from College.models import College, CollegeGallery, CourseFee, Eligibility, CollegeApplication,AdmissionBlog
from College.serializers import CollegeSerializer, CollegeGallerySerializer, CourseFeeSerializer, EligibilitySerializer, \
    FullCourseFeeSerializer, CollegeApplicationSerializer,BasicCollegeSerializer,CategoryCollegeSerializer,SingleAdmissionBlogSerializer
from django_filters import rest_framework as filters
from General.models import CourseCategory
from Exam.models import Exam

class CategoryCollegeView(APIView):
    def get(self, request):
        try:
            course_categories = CourseCategory.objects.all()
            serialized_data = []
            for category in course_categories:
                colleges = College.objects.filter(course_category=category)
                exams = Exam.objects.filter(course_category=category)
                serializer = CategoryCollegeSerializer({'course_category': category, 'colleges': colleges,'exams':exams})
                serialized_data.append(serializer.data)

            return Response(serialized_data)
        except CourseCategory.DoesNotExist:
            return Response({'error': 'No course categories found'}, status=404)


class CollegeListView(ListAPIView):
    queryset = College.objects.all()
    serializer_class = BasicCollegeSerializer
    permission_classes = (AllowAny,)
    filter_backends = [SearchFilter, DjangoFilterBackend]
    search_fields = ['name', 'organization_type__name',  'college_type__name',
                     'state__name', 'city', 'country__name']
    filterset_class = CollegeFilter



class CollegeRetrieveView(RetrieveAPIView):
    queryset = College.objects.all()
    serializer_class = CollegeSerializer
    # permission_classes = (IsAuthenticated,)
    lookup_field = 'slug'



class CollegeGalleryRetrieveView(RetrieveAPIView):
    queryset = CollegeGallery.objects.all()
    serializer_class = CollegeGallerySerializer
    permission_classes = (IsAuthenticated,)


class CourseFeeRetrieveView(RetrieveAPIView):
    queryset = CourseFee.objects.all()
    serializer_class = FullCourseFeeSerializer
    # permission_classes = (IsAuthenticated,)


class CourseFeeViewSet(viewsets.ModelViewSet):
    serializer_class = FullCourseFeeSerializer
    filter_class = CourseFeeFilter

    def get_queryset(self):
        queryset = CourseFee.objects.all()
        min_year_fees = self.request.query_params.get('min_year_fees')
        max_year_fees = self.request.query_params.get('max_year_fees')

        if min_year_fees is not None:
            queryset = queryset.filter(year_fees__gte=min_year_fees)
        if max_year_fees is not None:
            queryset = queryset.filter(year_fees__lte=max_year_fees)

        return queryset

class CollegeApplicationCreateView(generics.CreateAPIView):
    queryset = CollegeApplication.objects.all()
    serializer_class = CollegeApplicationSerializer
    permission_classes = (IsAuthenticated,)

class CollegeApplicationListView(generics.ListAPIView):
    queryset = CollegeApplication.objects.all()
    serializer_class = CollegeApplicationSerializer
    permission_classes = (IsAuthenticated,)
class StudentAppliedCollegesView(generics.ListAPIView):
    serializer_class = CollegeApplicationSerializer
    permission_classes = (IsAuthenticated,)
    def get_queryset(self):
        student = self.request.user.student  
        try:
            queryset = CollegeApplication.objects.filter(student=student)
            return queryset
        except CollegeAdmin.DoesNotExist:
            return CollegeApplication.objects.none()
        
class CollegeAppliedCollegesView(generics.ListAPIView):
    serializer_class = CollegeApplicationSerializer
    permission_classes = (IsAuthenticated,)
    def get_queryset(self):
        college_user = self.request.user.collegeadmin 
        try:
            queryset = CollegeApplication.objects.filter(college__college_user=college_user)
            return queryset
        except CollegeAdmin.DoesNotExist:
            return CollegeApplication.objects.none()
       

        
class EligibilityRetrieveView(RetrieveAPIView):
    queryset = Eligibility.objects.all()
    serializer_class = EligibilitySerializer
    permission_classes = (IsAuthenticated,)



class AdmissionBlogListFilter(filters.FilterSet):
    class Meta:
        model = AdmissionBlog
        fields = {'course_category': ['exact']}

class AdmissionBlogListView(ListAPIView):
    queryset = AdmissionBlog.objects.filter(status='PUBLIC')
    serializer_class = SingleAdmissionBlogSerializer
    permission_classes = [AllowAny]
    filter_backends = (filters.DjangoFilterBackend,)
    filterset_class = AdmissionBlogListFilter

class AdmissionBlogDetailView(RetrieveAPIView):
    queryset = AdmissionBlog.objects.filter(status='PUBLIC')
    serializer_class = SingleAdmissionBlogSerializer
    permission_classes = [AllowAny]
    lookup_field = 'slug'