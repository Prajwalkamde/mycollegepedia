from django.urls import path,include
from rest_framework import routers
from College.views import CollegeListView, CollegeRetrieveView, CollegeGalleryRetrieveView, CourseFeeRetrieveView, \
    EligibilityRetrieveView, CourseFeeViewSet, CollegeApplicationCreateView, CollegeApplicationListView, \
    StudentAppliedCollegesView,CollegeAppliedCollegesView,CategoryCollegeView,AdmissionBlogListView,AdmissionBlogDetailView,CollegeVideoRetrieveView,CollegeViewSet,CollegeGalleryViewSet,CollegeVideoViewSet,CourseFeeSet,CollegeAppliedViewSet,EligibilityViewSet,FAQViewSet

router = routers.DefaultRouter()
router.register(r'coursefees', CourseFeeViewSet,basename='coursefees')
router.register(r'college-detail', CollegeViewSet,basename='collegeview')
router.register(r'awards-achivements', CollegeGalleryViewSet,basename='awards-achivement')
router.register(r'intro-video', CollegeVideoViewSet,basename='intro-video')
router.register(r'course-fees', CourseFeeSet,basename='course-fees')
router.register(r'college-leads', CollegeAppliedViewSet,basename='college-leads')
router.register(r'college-eligibility', EligibilityViewSet,basename='college-eligibility')
router.register(r'college-faq', FAQViewSet,basename='college-faq')
urlpatterns = [
    path('all-college/',CollegeListView.as_view(),name='all_college'),
    path('college/<str:slug>/',CollegeRetrieveView.as_view(),name='college'),
    path('college-gallery/<int:college_id>/',CollegeGalleryRetrieveView.as_view(),name='college_gallery'),
    path('college-video/<int:college_id>/',CollegeVideoRetrieveView.as_view(),name='college_video'),
    path('course-fee/<int:pk>/',CourseFeeRetrieveView.as_view(),name='course_fee'),
    # path('course-fee/',CourseFeeViewSet.as_view({'get': 'retrieve'}),name='all_course_fee'),
    path('apply/', CollegeApplicationCreateView.as_view(), name='apply-to-college'),
    path('student-applied-colleges/', StudentAppliedCollegesView.as_view(), name='student-applied-colleges'),
    path('college-applied-colleges/', CollegeAppliedCollegesView.as_view(), name='college-applied-colleges'),
    path('applications/', CollegeApplicationListView.as_view(), name='college-applications'),
    path('eligibility/<int:pk>/',EligibilityRetrieveView.as_view(),name='eligibility'),
    path('category-colleges/', CategoryCollegeView.as_view(), name='category_colleges'),
    path('admission-blog/', AdmissionBlogListView.as_view(), name='admission_blog'),
    path('admission-blog-detail/<str:slug>/', AdmissionBlogDetailView.as_view(), name='admission_blog_detail'),
    path('', include(router.urls)),
]
