from django.shortcuts import render
from rest_framework.generics import RetrieveAPIView, ListAPIView
from Exam.serializers import ExamSerializer, SimpleExamSerializer, UpcomingExamSerializer, SimpleUpcomingExamSerializer, \
    AllExamSerializer
from Exam.models import Exam, UpcomingExam


# Create your views here.
class ExamListView(ListAPIView):
    queryset = Exam.objects.all()
    serializer_class = ExamSerializer


class ExamRetrieveView(RetrieveAPIView):
    queryset = Exam.objects.all()
    serializer_class = ExamSerializer
    lookup_field = 'slug'


class UpcomingExamListView(ListAPIView):
    queryset = UpcomingExam.objects.all()
    serializer_class = UpcomingExamSerializer


class UpcomingExamRetrieveView(RetrieveAPIView):
    queryset = UpcomingExam.objects.all()
    serializer_class = AllExamSerializer
    lookup_field = 'slug'
