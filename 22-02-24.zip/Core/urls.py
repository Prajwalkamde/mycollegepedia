from django.urls import path
from .views import SiteConfigView,AboutView,SliderListView,ContactCreateView,PrivacyPolicyView,TermsAndConditionView,TestimonialListView

urlpatterns = [
    path('site-config/', SiteConfigView.as_view(), name='site-config'),
    path('about/', AboutView.as_view(), name='about'),
    path('slider/', SliderListView.as_view(), name='slider'),
    path('contact/', ContactCreateView.as_view(), name='contact'),
    path('privacy/', PrivacyPolicyView.as_view(), name='privacy'),
    path('terms/', TermsAndConditionView.as_view(), name='terms'),
    path('testimonial/', TestimonialListView.as_view(), name='testimonial'),
]
